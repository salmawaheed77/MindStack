import argparse
import base64
import time
import wave

import ormsgpack
import pyaudio
import requests
from pydub import AudioSegment
from pydub.playback import play

from fish_speech.utils.file import audio_to_bytes, read_ref_text
from fish_speech.utils.schema import ServeReferenceAudio, ServeTTSRequest


def parse_args():
    parser = argparse.ArgumentParser(
        description="Send text to a Fish Speech TTS server and receive synthesized audio.",
        epilog=(
            "Model selection note:\n"
            "  The base TTS model is selected by the server you call. For example, if the\n"
            "  server was started with checkpoints/s2-pro, this client will use S2-Pro\n"
            "  automatically. There is no separate per-request --model flag.\n\n"
            "Examples:\n"
            '  python tools/api_client.py -u http://127.0.0.1:8080/v1/tts -t "Hello from Fish Speech"\n'
            '  python tools/api_client.py -u http://127.0.0.1:8080/v1/tts -t "Hello" --reference_id my-speaker'
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )

    parser.add_argument(
        "--url",
        "-u",
        type=str,
        default="http://127.0.0.1:8080/v1/tts",
        help="URL of the TTS server. The server decides which base model is loaded.",
    )
    parser.add_argument(
        "--text", "-t", type=str, required=True, help="Text to be synthesized"
    )
    parser.add_argument(
        "--reference_id",
        "-id",
        type=str,
        default=None,
        help="ID of the reference voice to use for synthesis\n(Local: name of folder containing audios and files)",
    )
    parser.add_argument(
        "--reference_audio",
        "-ra",
        type=str,
        nargs="+",
        default=None,
        help="Path to the audio file",
    )
    parser.add_argument(
        "--reference_text",
        "-rt",
        type=str,
        nargs="+",
        default=None,
        help="Reference text for voice synthesis",
    )
    parser.add_argument(
        "--reference_speaker",
        "-rs",
        type=int,
        nargs="+",
        default=None,
        help="Speaker ID (0-15) of each reference audio, written as <|speaker:N|> "
        "before reference texts that do not start with a speaker tag",
    )
    parser.add_argument(
        "--output",
        "-o",
        type=str,
        default="generated_audio",
        help="Output audio file name",
    )
    parser.add_argument(
        "--play",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Whether to play audio after receiving data",
    )
    parser.add_argument(
        "--format", type=str, choices=["wav", "pcm", "mp3", "opus"], default="wav"
    )
    parser.add_argument(
        "--latency",
        type=str,
        default="normal",
        choices=["normal", "balanced"],
        help="Used in api.fish.audio/v1/tts",
    )
    # Sampling: unset means the server uses the loaded model family's defaults.
    parser.add_argument(
        "--max_new_tokens",
        type=int,
        default=None,
        help="Maximum new tokens to generate per text chunk. Unset uses the "
        "server's default, 1024; 0 means the model's own cap (S2-Pro: the context "
        "length; Drama 3: 600 per chunk, 2048 with --single_chunk).",
    )
    parser.add_argument(
        "--single_chunk",
        action="store_true",
        help="Drama 3 only: generate the whole text in one pass instead of chunks",
    )
    parser.add_argument(
        "--chunk_length",
        type=int,
        default=200,
        help="Chunk length for synthesis (S2-Pro only; Drama 3 uses ~300-byte chunks)",
    )
    parser.add_argument(
        "--top_p", type=float, default=None, help="Top-p sampling for synthesis"
    )
    parser.add_argument(
        "--repetition_penalty",
        type=float,
        default=None,
        help="Accepted for compatibility; S2-Pro and Drama 3 ignore it and use "
        "repetition-aware sampling",
    )
    parser.add_argument(
        "--temperature", type=float, default=None, help="Temperature for sampling"
    )

    # parser.add_argument("--streaming", type=bool, default=False, help="Enable streaming response")
    parser.add_argument(
        "--streaming", action="store_true", help="Enable streaming response"
    )
    parser.add_argument(
        "--channels", type=int, default=1, help="Number of audio channels"
    )
    parser.add_argument("--rate", type=int, default=44100, help="Sample rate for audio")
    parser.add_argument(
        "--use_memory_cache",
        type=str,
        default="off",
        choices=["on", "off"],
        help="Cache encoded references codes in memory.\n",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=None,
        help="`None` means randomized inference, otherwise deterministic.\nIt can't be used for fixing a timbre.",
    )
    parser.add_argument(
        "--api_key",
        type=str,
        default="YOUR_API_KEY",
        help="API key for authentication",
    )

    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    idstr: str | None = args.reference_id
    # priority: ref_id > [{text, audio},...]
    if idstr is None:
        ref_audios = args.reference_audio or []
        ref_texts = args.reference_text or []

        if len(ref_audios) != len(ref_texts):
            raise SystemExit(
                "--reference_audio and --reference_text must be given the same number "
                f"of values, got {len(ref_audios)} audio(s) and {len(ref_texts)} text(s)."
            )

        byte_audios = []
        for ref_audio in ref_audios:
            audio_bytes = audio_to_bytes(ref_audio)
            if audio_bytes is None:
                raise SystemExit(f"Reference audio file not found: {ref_audio}")
            byte_audios.append(audio_bytes)

        ref_texts = [read_ref_text(ref_text) for ref_text in ref_texts]
        ref_speakers = args.reference_speaker or [None] * len(ref_audios)
        if len(ref_speakers) != len(ref_audios):
            raise SystemExit(
                "--reference_speaker must be given once per --reference_audio, got "
                f"{len(ref_speakers)} speaker(s) and {len(ref_audios)} audio(s)."
            )
    else:
        byte_audios = []
        ref_texts = []
        ref_speakers = []
        pass  # in api.py

    data = {
        "text": args.text,
        "references": [
            ServeReferenceAudio(audio=ref_audio, text=ref_text, speaker=speaker)
            for ref_text, ref_audio, speaker in zip(
                ref_texts, byte_audios, ref_speakers
            )
        ],
        "reference_id": idstr,
        "format": args.format,
        "latency": args.latency,
        "max_new_tokens": args.max_new_tokens,
        "chunk_length": args.chunk_length,
        "single_chunk": args.single_chunk,
        "top_p": args.top_p,
        "repetition_penalty": args.repetition_penalty,
        "temperature": args.temperature,
        "streaming": args.streaming,
        "use_memory_cache": args.use_memory_cache,
        "seed": args.seed,
    }

    pydantic_data = ServeTTSRequest(**data)

    print("Sending request")
    start_time = time.time()
    response = requests.post(
        args.url,
        params={"format": "msgpack"},
        # Unset (None) fields are left out so servers that predate optional sampling
        # fields fall back to their own defaults instead of rejecting null.
        data=ormsgpack.packb(pydantic_data.model_dump(exclude_none=True)),
        stream=args.streaming,
        headers={
            "authorization": f"Bearer {args.api_key}",
            "content-type": "application/msgpack",
        },
    )
    end_time = time.time()
    print(f"Request took {end_time - start_time} seconds")

    if response.status_code == 200:
        if args.streaming:
            p = pyaudio.PyAudio()
            audio_format = pyaudio.paInt16  # Assuming 16-bit PCM format
            stream = p.open(
                format=audio_format, channels=args.channels, rate=args.rate, output=True
            )

            wf = wave.open(f"{args.output}.wav", "wb")
            wf.setnchannels(args.channels)
            wf.setsampwidth(p.get_sample_size(audio_format))
            wf.setframerate(args.rate)

            stream_stopped_flag = False
            # The server opens the stream with a 44-byte WAV header (older ones
            # did not); only the samples after it are played and saved.
            header = b""

            try:
                for chunk in response.iter_content(chunk_size=1024):
                    if header is not None:
                        header += chunk
                        if len(header) < 44:
                            continue
                        chunk = header[44:] if header.startswith(b"RIFF") else header
                        header = None
                    if chunk:
                        stream.write(chunk)
                        wf.writeframesraw(chunk)
                    else:
                        if not stream_stopped_flag:
                            stream.stop_stream()
                            stream_stopped_flag = True
            finally:
                stream.close()
                p.terminate()
                wf.close()
        else:
            audio_content = response.content
            audio_path = f"{args.output}.{args.format}"
            with open(audio_path, "wb") as audio_file:
                audio_file.write(audio_content)

            if args.format == "pcm":  # headerless 16-bit mono
                audio = AudioSegment.from_file(
                    audio_path,
                    format="raw",
                    sample_width=2,
                    frame_rate=args.rate,
                    channels=1,
                )
            else:  # opus comes in an Ogg container
                audio = AudioSegment.from_file(
                    audio_path, format="ogg" if args.format == "opus" else args.format
                )
            if args.play:
                play(audio)
            print(f"Audio has been saved to '{audio_path}'.")
    else:
        print(f"Request failed with status code {response.status_code}")
        print(response.json())
