#!/bin/bash
# Quick automated test for myshell
make > /dev/null || exit 1
echo "---- Running tests ----"
printf 'pwd\necho hello\nls\ncd /tmp\npwd\necho test > out.txt\ncat out.txt\nls | wc -l\nsleep 1 &\nfoo_not_exist\nexit\n' | ./myshell
rm -f out.txt /tmp/out.txt
echo "---- Done ----"
