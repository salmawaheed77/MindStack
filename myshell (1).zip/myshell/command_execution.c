// Command Execution - Mini Shell for Ubuntu/Linux
// Compile: gcc -Wall -o myshell command_execution.c
// Run:     ./myshell

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>

#define MAX_ARGS 64
#define MAX_LINE 1024

// ---------- 1) Parsing: قسّم السطر لكلمات ----------
int parse(char *line, char **args) {
    int n = 0;
    char *tok = strtok(line, " \t");
    while (tok && n < MAX_ARGS - 1) {
        args[n++] = tok;
        tok = strtok(NULL, " \t");
    }
    args[n] = NULL;
    return n;
}

// ---------- 2) Built-in commands: الشيل بينفذها بنفسه ----------
// بترجع 1 لو الأمر built-in واتنفذ، و 0 لو مش built-in
int run_builtin(char **args) {
    if (strcmp(args[0], "exit") == 0) {
        exit(0);
    }
    if (strcmp(args[0], "cd") == 0) {
        const char *dir = args[1] ? args[1] : getenv("HOME");
        if (chdir(dir) != 0) perror("cd");
        return 1;
    }
    if (strcmp(args[0], "pwd") == 0) {
        char cwd[512];
        if (getcwd(cwd, sizeof(cwd))) printf("%s\n", cwd);
        return 1;
    }
    if (strcmp(args[0], "help") == 0) {
        printf("Built-in: cd, pwd, help, exit\n");
        printf("Supports: external commands, &, >, >>, <, single pipe |\n");
        return 1;
    }
    return 0;
}

// ---------- 3) Redirection: > >> < ----------
void handle_redirection(char **args) {
    for (int i = 0; args[i]; i++) {
        int fd = -1;
        if (strcmp(args[i], ">") == 0 && args[i + 1]) {
            fd = open(args[i + 1], O_WRONLY | O_CREAT | O_TRUNC, 0644);
            dup2(fd, STDOUT_FILENO);
        } else if (strcmp(args[i], ">>") == 0 && args[i + 1]) {
            fd = open(args[i + 1], O_WRONLY | O_CREAT | O_APPEND, 0644);
            dup2(fd, STDOUT_FILENO);
        } else if (strcmp(args[i], "<") == 0 && args[i + 1]) {
            fd = open(args[i + 1], O_RDONLY);
            dup2(fd, STDIN_FILENO);
        } else {
            continue;
        }
        if (fd < 0) { perror("open"); exit(1); }
        close(fd);
        args[i] = NULL;   // قص الأمر عند علامة الـ redirection
        break;
    }
}

// ---------- 4) تنفيذ أمر خارجي: fork + exec + wait ----------
void run_external(char **args, int background) {
    pid_t pid = fork();
    if (pid == 0) {                       // child
        handle_redirection(args);
        execvp(args[0], args);
        fprintf(stderr, "%s: command not found\n", args[0]);
        exit(127);
    } else if (pid > 0) {                 // parent
        if (background)
            printf("[background pid %d]\n", pid);
        else
            waitpid(pid, NULL, 0);
    } else {
        perror("fork");
    }
}

// ---------- 5) Pipe: cmd1 | cmd2 ----------
void run_pipe(char **left, char **right) {
    int fd[2];
    if (pipe(fd) < 0) { perror("pipe"); return; }

    pid_t p1 = fork();
    if (p1 == 0) {
        dup2(fd[1], STDOUT_FILENO);
        close(fd[0]); close(fd[1]);
        execvp(left[0], left);
        perror(left[0]); exit(1);
    }
    pid_t p2 = fork();
    if (p2 == 0) {
        dup2(fd[0], STDIN_FILENO);
        close(fd[0]); close(fd[1]);
        execvp(right[0], right);
        perror(right[0]); exit(1);
    }
    close(fd[0]); close(fd[1]);
    waitpid(p1, NULL, 0);
    waitpid(p2, NULL, 0);
}

// ---------- Main loop ----------
int main(void) {
    char line[MAX_LINE];
    char *args[MAX_ARGS];

    while (1) {
        char cwd[512];
        getcwd(cwd, sizeof(cwd));
        printf("myshell:%s$ ", cwd);
        fflush(stdout);

        if (!fgets(line, sizeof(line), stdin)) { printf("\n"); break; }
        line[strcspn(line, "\n")] = 0;

        int n = parse(line, args);
        if (n == 0) continue;

        // هل في pipe؟
        int pipe_idx = -1;
        for (int i = 0; i < n; i++)
            if (strcmp(args[i], "|") == 0) { pipe_idx = i; break; }
        if (pipe_idx > 0 && args[pipe_idx + 1]) {
            args[pipe_idx] = NULL;
            run_pipe(args, &args[pipe_idx + 1]);
            continue;
        }

        // هل في & في الآخر؟
        int background = 0;
        if (strcmp(args[n - 1], "&") == 0) {
            background = 1;
            args[n - 1] = NULL;
            if (n == 1) continue;
        }

        if (run_builtin(args)) continue;
        run_external(args, background);
    }
    return 0;
}
