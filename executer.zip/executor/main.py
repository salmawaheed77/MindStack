"""Optional line-oriented CLI for manually exercising the executor.

Run from the project root with: python3 -m executor.main
"""

import json
import sys

from .executor import execute_command


def main() -> None:
    print("Sound OS Command Executor")
    print("Enter one JSON command per line. Type 'exit' to quit.")
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        if line.casefold() == "exit":
            break
        try:
            payload = json.loads(line)
            result = execute_command(payload)
        except json.JSONDecodeError as exc:
            result = {"success": False, "error": "invalid_json", "message": f"Invalid JSON: {exc.msg}"}
        print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
