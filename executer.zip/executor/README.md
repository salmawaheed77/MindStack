# Sound OS — Executor Module (updated)

This folder is the structured command-execution layer for Sound OS. It does **not** contain STT, NLP, GUI code, or a general-purpose shell.

## What changed in this version

- Fixed package imports: use `executor.executor`, not the old/nonexistent `command_executor` package.
- Kept a single public entry point: `execute_command(payload)`.
- Added `get_cpu_usage` and `get_processes` actions to match the GUI command catalogue.
- Tightened workspace path checks and reject symbolic links in user-supplied paths.
- Prevented accidental overwrites in create, copy, move, and rename operations.
- Fixed nested-folder rename path handling.
- Made confirmation failures explicit with `error="confirmation_required"` and `confirmation_required=true`.
- Added clearer error codes and tests.
- Kept application launching allowlisted and all subprocess calls shell-free.

## Requirements

- Python 3.10+
- Ubuntu/Linux for `/proc`-based CPU, memory, and process information
- Optional OS utilities depending on the action: `ps`, `pkill`, `loginctl`, `systemctl`, `nmcli`, `wpctl` or `pactl`, `brightnessctl`, and installed desktop applications.

Example Ubuntu packages:

```bash
sudo apt update
sudo apt install procps util-linux network-manager
# Optional brightness control:
sudo apt install brightnessctl
```

Audio controls use `wpctl` (PipeWire) or `pactl` (PulseAudio), if available.

## Workspace and file safety

All file operations are restricted to `~/SoundOS_Workspace`. Relative paths are recommended:

```json
{"action":"create_folder","path":"College"}
{"action":"create_file","path":"College/notes.txt","content":"My notes"}
{"action":"read_file","path":"College/notes.txt"}
```

The executor rejects paths that escape the workspace and rejects symbolic-link components. It does not overwrite an existing destination. Choose a new destination name instead.

Deleting files/folders and logging out, restarting, or shutting down require explicit approval. The caller must obtain approval from the user for the **exact pending action**, then resend the same payload with `confirmed: true`.

```json
{"action":"delete_file","path":"College/notes.txt"}
```

The first call returns `error="confirmation_required"`. Only after user approval should the caller send:

```json
{"action":"delete_file","path":"College/notes.txt","confirmed":true}
```

Never set `confirmed=true` automatically or merely because a settings toggle disables confirmation dialogs.

## Supported actions

| Category | Actions |
|---|---|
| Applications | `open_application`, `close_application`, `list_running_applications` |
| Files | `create_folder`, `create_file`, `read_file`, `copy_file`, `move_file`, `rename_file`, `delete_file`, `delete_folder`, `search_files`, `list_files` |
| Browser | `open_website`, `google_search` |
| System | `get_date_time`, `get_cpu_usage`, `get_disk_usage`, `get_memory_usage`, `get_processes`, `get_system_info`, `lock_screen`, `logout`, `restart_system`, `shutdown_system` |
| Devices | `volume_up`, `volume_down`, `volume_mute`, `brightness_up`, `brightness_down`, `wifi_on`, `wifi_off` |

Application names are allowlisted in `app_manager.py`. `browser` is an alias for Firefox. Add an application only by deliberately editing that allowlist.

## Integration from the project root

```python
from executor.executor import execute_command

result = execute_command({"action": "get_cpu_usage"})
if result["success"]:
    print(result.get("data"))
else:
    print(result["error"], result["message"])
```

The future GUI/Main integration should pass structured dictionaries to `execute_command`. NLP should produce an action and its required fields; it should not produce a raw shell string.

The separate project `security/security_gate.py` currently validates **shell-command text**, whereas this executor accepts **structured action dictionaries**. They are different interfaces: do not pass an action dictionary to `validate_command`, and do not send raw shell commands to this executor. Keep the text Security Gate upstream only if that part of the pipeline is intentionally processing shell-command text; the executor still enforces its own payload and workspace protections.

## Run the optional command-line interface

From the project root:

```bash
python3 -m executor.main
```

Enter one JSON object per line. Type `exit` to quit.

## Tests

From the project root:

```bash
python3 -m unittest executor.test_executor -v
```

These tests cover payload validation, path traversal, symlink rejection, overwrite protection, file operations, confirmation handling, and action registration. They do not test every installed desktop utility or physical device.
