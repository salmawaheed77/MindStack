"""Allowlisted desktop application launching and closing."""

import shutil
import subprocess

# Friendly name -> (executable, exact process name used by pkill -x).
APPS = {
    "calculator": ("gnome-calculator", "gnome-calculator"),
    "firefox": ("firefox", "firefox"),
    "browser": ("firefox", "firefox"),
    "files": ("nautilus", "nautilus"),
    "file_manager": ("nautilus", "nautilus"),
    "text_editor": ("gedit", "gedit"),
    "gedit": ("gedit", "gedit"),
    "terminal": ("gnome-terminal", "gnome-terminal"),
    "vlc": ("vlc", "vlc"),
    "libreoffice": ("libreoffice", "soffice"),
    "code": ("code", "code"),
}


def _get_app(target):
    if not isinstance(target, str) or not target.strip():
        raise ValueError("Please provide an application target.")
    key = target.strip().casefold().replace(" ", "_")
    if key not in APPS:
        raise ValueError(
            f"'{target}' is not in the allowed application list. "
            f"Allowed apps: {', '.join(sorted(APPS))}"
        )
    return key, APPS[key]


def open_application(payload: dict) -> dict:
    key, (executable, _) = _get_app(payload.get("target"))
    path = shutil.which(executable)
    if path is None:
        return {"success": False, "error": "application_not_installed", "message": f"{key} is allowed but '{executable}' is not installed."}
    try:
        subprocess.Popen([path], start_new_session=True, close_fds=True)
    except OSError as exc:
        return {"success": False, "error": "application_launch_failed", "message": str(exc)}
    return {"success": True, "message": f"Opening {key}."}


def close_application(payload: dict) -> dict:
    key, (_, process_name) = _get_app(payload.get("target"))
    pkill = shutil.which("pkill")
    if pkill is None:
        raise RuntimeError("pkill is not available on this system.")
    result = subprocess.run([pkill, "-x", process_name], capture_output=True, text=True, check=False, timeout=10)
    if result.returncode == 0:
        return {"success": True, "message": f"Close signal sent to {key}."}
    if result.returncode == 1:
        return {"success": False, "error": "not_running", "message": f"{key} is not running."}
    return {"success": False, "error": "close_failed", "message": result.stderr.strip() or "Unable to close the application."}


def list_running_applications(payload: dict) -> dict:
    del payload
    ps = shutil.which("ps")
    if ps is None:
        raise RuntimeError("The 'ps' utility is not installed.")
    result = subprocess.run([ps, "-eo", "comm="], capture_output=True, text=True, check=True, timeout=10)
    running = {line.strip() for line in result.stdout.splitlines() if line.strip()}
    known = sorted({process for _, process in APPS.values() if process in running})
    return {"success": True, "message": "Running applications retrieved.", "data": known}
