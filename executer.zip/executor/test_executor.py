"""Unit tests for the executor package. Run: python3 -m unittest executor.test_executor -v"""

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from . import security
from .executor import execute_command, get_supported_actions


class ExecutorTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.workspace = Path(self.temp_dir.name).resolve()
        self.workspace_patch = patch.object(security, "WORKSPACE", self.workspace)
        self.workspace_patch.start()

    def tearDown(self):
        self.workspace_patch.stop()
        self.temp_dir.cleanup()

    def test_non_object_payload_is_rejected(self):
        result = execute_command(["get_date_time"])
        self.assertFalse(result["success"])
        self.assertEqual(result["error"], "validation_error")

    def test_missing_action_is_rejected(self):
        result = execute_command({})
        self.assertEqual(result["error"], "validation_error")

    def test_unknown_action(self):
        result = execute_command({"action": "do_magic"})
        self.assertFalse(result["success"])
        self.assertEqual(result["error"], "unsupported_action")

    def test_raw_shell_is_rejected(self):
        result = execute_command({"action": "open_application", "target": "firefox", "command": "rm -rf /"})
        self.assertFalse(result["success"])
        self.assertEqual(result["error"], "permission_denied")

    def test_create_and_read_file(self):
        created = execute_command({"action": "create_file", "path": "notes/hello.txt", "content": "hello"})
        self.assertTrue(created["success"], created)
        read = execute_command({"action": "read_file", "path": "notes/hello.txt"})
        self.assertTrue(read["success"], read)
        self.assertEqual(read["data"], "hello")

    def test_create_file_does_not_overwrite(self):
        (self.workspace / "same.txt").write_text("original", encoding="utf-8")
        result = execute_command({"action": "create_file", "path": "same.txt", "content": "replacement"})
        self.assertEqual(result["error"], "already_exists")
        self.assertEqual((self.workspace / "same.txt").read_text(encoding="utf-8"), "original")

    def test_path_traversal_is_rejected(self):
        result = execute_command({"action": "create_file", "path": "../outside.txt", "content": "no"})
        self.assertEqual(result["error"], "permission_denied")

    def test_symlink_path_is_rejected(self):
        outside = self.workspace.parent / "outside_executor_test.txt"
        outside.write_text("safe", encoding="utf-8")
        link = self.workspace / "link.txt"
        link.symlink_to(outside)
        try:
            result = execute_command({"action": "read_file", "path": "link.txt"})
            self.assertEqual(result["error"], "permission_denied")
        finally:
            outside.unlink(missing_ok=True)

    def test_copy_does_not_overwrite(self):
        (self.workspace / "source.txt").write_text("source", encoding="utf-8")
        (self.workspace / "target.txt").write_text("target", encoding="utf-8")
        result = execute_command({"action": "copy_file", "source": "source.txt", "destination": "target.txt"})
        self.assertEqual(result["error"], "already_exists")
        self.assertEqual((self.workspace / "target.txt").read_text(encoding="utf-8"), "target")

    def test_rename_nested_file(self):
        folder = self.workspace / "class"
        folder.mkdir()
        (folder / "old.txt").write_text("x", encoding="utf-8")
        result = execute_command({"action": "rename_file", "path": "class/old.txt", "new_name": "new.txt"})
        self.assertTrue(result["success"], result)
        self.assertTrue((folder / "new.txt").is_file())

    def test_delete_requires_confirmation(self):
        (self.workspace / "delete.txt").write_text("x", encoding="utf-8")
        result = execute_command({"action": "delete_file", "path": "delete.txt"})
        self.assertEqual(result["error"], "confirmation_required")
        self.assertTrue((self.workspace / "delete.txt").exists())

    def test_delete_with_confirmation(self):
        (self.workspace / "delete.txt").write_text("x", encoding="utf-8")
        result = execute_command({"action": "delete_file", "path": "delete.txt", "confirmed": True})
        self.assertTrue(result["success"], result)
        self.assertFalse((self.workspace / "delete.txt").exists())

    def test_workspace_root_cannot_be_deleted(self):
        result = execute_command({"action": "delete_folder", "path": ".", "confirmed": True})
        self.assertEqual(result["error"], "permission_denied")

    def test_cpu_and_process_actions_are_registered(self):
        actions = get_supported_actions()
        self.assertIn("get_cpu_usage", actions)
        self.assertIn("get_processes", actions)


if __name__ == "__main__":
    unittest.main()
